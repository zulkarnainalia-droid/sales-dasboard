# Frontend (Vite + React)

## Setup
1. `cd frontend`
2. `npm install`
3. Create `.env` if you want to set `VITE_API_BASE` to your backend base URL.
4. `npm run dev` to start dev server (default port 5173).
